import {Lightbox} from "./Lightbox";

export class PhotonicThickbox extends Lightbox {
	constructor($) {
		super();
		this.$ = $;
	}
}