<?php
/*
Plugin Name: Portfolio MC
Description: Motor Flickr encapsulado con layout visual y selector de álbumes.
Version: 1.0
Author: Pablo Eckert
*/

require_once plugin_dir_path(__FILE__) . 'engine/flickr/FlickrPlatform.php';
require_once plugin_dir_path(__FILE__) . 'engine/flickr/FlickrOptions.php';
